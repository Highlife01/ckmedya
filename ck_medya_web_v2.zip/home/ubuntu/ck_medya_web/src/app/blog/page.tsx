import Link from 'next/link';
import { motion } from 'framer-motion';
import { FiCalendar, FiTag, FiArrowRight } from 'react-icons/fi'; // Example icons

export const metadata = {
  title: 'Blog - CK Medya İletişim Menajerlik',
  description: 'CK Medya Blog: Dijital pazarlama, influencer iletişimi, sosyal medya stratejileri ve daha birçok konuda en güncel bilgiler, uzman analizleri ve pratik ipuçları.',
};

// Animation variants
const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.8 } },
};

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const BlogPage = () => {
  const posts = [
    {
      id: 1,
      title: "2025 Influencer Marketing Trendleri: Markanız Geri Kalmasın!",
      slug: "influencer-marketing-trendleri-2025",
      date: "15 Nisan 2025",
      excerpt: "Influencer marketing dünyası sürekli değişiyor ve gelişiyor. Bu yazımızda, 2025 yılında markaların dikkat etmesi gereken en önemli influencer pazarlama trendlerini inceliyoruz.",
      category: "Influencer Marketing",
      image: "/placeholder-blog1.jpg" // Placeholder image
    },
    {
      id: 2,
      title: "Sosyal Medyada Etkileşim Sanatı: Takipçilerinizi Nasıl Hayranlara Dönüştürürsünüz?",
      slug: "sosyal-medyada-etkilesim-sanati",
      date: "22 Nisan 2025",
      excerpt: "Yüksek takipçi sayısı her zaman yeterli değildir. Önemli olan, bu takipçilerle gerçek bir etkileşim kurmaktır. Etkileşiminizi artırmanın kanıtlanmış yollarını paylaşıyoruz.",
      category: "Sosyal Medya Yönetimi",
      image: "/placeholder-blog2.jpg"
    },
    {
      id: 3,
      title: "Kriz Anında Dijital İtibar Yönetimi: Markanızı Nasıl Korursunuz?",
      slug: "kriz-aninda-dijital-itibar-yonetimi",
      date: "30 Nisan 2025",
      excerpt: "Hiçbir marka krizlerden muaf değildir. Önemli olan, kriz anında doğru adımları atarak markanızın itibarını koruyabilmektir. Pratik ve etkili stratejiler sunuyoruz.",
      category: "Dijital PR",
      image: "/placeholder-blog3.jpg"
    },
    {
      id: 4,
      title: "İçerik Pazarlamasında Video Kullanımının Önemi",
      slug: "icerik-pazarlamasinda-video-kullanimi",
      date: "05 Mayıs 2025",
      excerpt: "Video içerikler, kullanıcı etkileşimini ve marka mesajının akılda kalıcılığını artırmada son derece etkilidir. Başarılı video pazarlama stratejileri için ipuçları.",
      category: "İçerik Pazarlaması",
      image: "/placeholder-blog4.jpg"
    }
  ];

  const categories = ["Influencer Marketing", "Sosyal Medya", "Dijital PR", "İçerik Pazarlaması", "SEO", "Trendler", "Marka Yönetimi"];

  return (
    <div className="space-y-16 md:space-y-24 pb-16">
      <motion.section 
        className="text-center py-16 md:py-20 px-4 bg-gradient-to-br from-ck-pale-blue via-ck-lavender to-ck-mint-green rounded-xl shadow-xl"
        variants={fadeIn}
        initial="hidden"
        animate="visible"
      >
        <motion.h1 
          className="text-4xl md:text-6xl font-bold mb-6 text-ck-dark-text drop-shadow-sm"
          variants={fadeInUp}
        >
          CK Medya Blog
        </motion.h1>
        <motion.p 
          className="text-lg md:text-xl text-ck-dark-text/80 max-w-3xl mx-auto"
          variants={fadeInUp}
        >
          Dijital dünyadan en son haberler, uzman görüşleri ve markanız için değerli ipuçları. Bilgi paylaştıkça çoğalır; okuyun, öğrenin, uygulayın ve markanızla fark yaratın!
        </motion.p>
      </motion.section>

      <motion.section 
        className="container mx-auto px-4"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
      >
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10 mb-16 md:mb-20">
          {posts.map((post) => (
            <motion.div 
              key={post.id} 
              className="bg-ck-white rounded-xl shadow-lg overflow-hidden flex flex-col hover:shadow-2xl transition-all duration-300 border border-ck-light-gray/50 group"
              variants={fadeInUp}
              whileHover={{ y: -5, transition: { type: "spring", stiffness: 300 } }}
            >
              <Link href={`/blog/${post.slug}`} className="block h-56 md:h-64 w-full overflow-hidden">
                <img 
                  src={post.image || "/placeholder-image.png"} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-in-out"
                />
              </Link>
              <div className="p-6 md:p-8 flex-grow flex flex-col">
                <div className="mb-3 flex items-center text-xs text-ck-dark-text/60 space-x-3">
                  <span className="flex items-center"><FiCalendar className="mr-1.5" /> {post.date}</span>
                  <span className="flex items-center"><FiTag className="mr-1.5" /> {post.category}</span>
                </div>
                <h2 className="text-xl md:text-2xl font-bold mb-3 text-ck-dark-text hover:text-ck-coral transition-colors">
                  <Link href={`/blog/${post.slug}`}>{post.title}</Link>
                </h2>
                <p className="text-ck-dark-text/70 text-sm mb-5 leading-relaxed flex-grow">{post.excerpt}</p>
                <Link 
                  href={`/blog/${post.slug}`} 
                  className="text-ck-coral hover:text-opacity-80 font-semibold inline-flex items-center self-start mt-auto group-hover:translate-x-1 transition-transform"
                >
                  Devamını Oku <FiArrowRight className="ml-1.5" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>
      
      <motion.section 
        className="container mx-auto px-4 mb-16 md:mb-20 p-6 md:p-8 bg-ck-light-gray/70 rounded-xl shadow-lg"
        variants={fadeInUp}
        initial="hidden"
        animate="visible"
      >
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 text-ck-dark-text">Kategoriler</h2>
        <div className="flex flex-wrap justify-center gap-3 md:gap-4">
          {categories.map(cat => (
            <Link 
              key={cat} 
              href={`/blog/kategori/${cat.toLowerCase().replace(/ /g, '-')}`} 
              className="bg-ck-white text-ck-coral border border-ck-coral/50 px-4 py-2 rounded-lg text-sm hover:bg-ck-coral hover:text-ck-white transition-all duration-300 shadow-sm hover:shadow-md transform hover:scale-105"
            >
              {cat}
            </Link>
          ))}
        </div>
      </motion.section>

      <motion.section 
        className="container mx-auto py-12 md:py-16 px-6 md:px-8 bg-gradient-to-r from-ck-coral to-ck-bright-yellow text-ck-white rounded-xl shadow-xl text-center"
        variants={fadeIn}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold mb-4"
          variants={fadeInUp}
        >
          Daha Fazla İçerik İçin Takipte Kalın!
        </motion.h2>
        <motion.p 
          className="text-lg md:text-xl mb-8 max-w-2xl mx-auto opacity-90"
          variants={fadeInUp}
        >
          Yeni yazılarımızdan ve sektördeki gelişmelerden anında haberdar olmak için bültenimize abone olabilir veya sosyal medya hesaplarımızı takip edebilirsiniz.
        </motion.p>
        <motion.div variants={fadeInUp}>
          <Link 
            href="/iletisim#form" 
            className="bg-ck-white text-ck-coral font-bold py-3 px-8 rounded-lg hover:bg-opacity-95 transition duration-300 text-lg shadow-md hover:shadow-lg transform hover:scale-105"
          >
            Bize Ulaşın
          </Link>
        </motion.div>
      </motion.section>
    </div>
  );
};

export default BlogPage;

