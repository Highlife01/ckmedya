import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton"; // Import WhatsAppButton

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "CK Medya İletişim Menajerlik",
  description: "CK Medya: Dijital Dünyada Markanızın Parlayan Yıldızı!",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body className={`${inter.className} bg-gray-100 text-gray-900`}>
        <Navbar />
        <main className="container mx-auto px-4 py-8 min-h-screen">
          {children}
        </main>
        <Footer />
        <WhatsAppButton /> {/* Add WhatsAppButton here */}
      </body>
    </html>
  );
}

