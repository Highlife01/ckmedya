import React from 'react';
import { FaEnvelope, FaPhone, FaMapMarkerAlt, FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from 'react-icons/fa'; // Assuming you're using react-icons

export const metadata = {
  title: 'İletişim - CK Medya İletişim Menajerlik',
  description: 'CK Medya İletişim Menajerlik ile iletişime geçin. Projeleriniz, işbirliği olanakları veya sadece bir merhaba demek için buradayız.',
};

const ContactPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-ck-pale-blue via-ck-lavender to-ck-mint-green py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-ck-dark-text drop-shadow-md">Bize Ulaşın</h1>
          <p className="mt-4 text-lg text-ck-dark-text/80">
            Projeleriniz, işbirliği olanakları veya aklınızdaki herhangi bir soru için bizimle iletişime geçmekten çekinmeyin. CK Medya olarak size yardımcı olmaktan mutluluk duyarız.
          </p>
        </header>

        <div className="grid md:grid-cols-2 gap-10 items-start">
          {/* Contact Form Section */}
          <motion.div 
            className="bg-white/80 backdrop-blur-md p-8 rounded-xl shadow-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h2 className="text-2xl font-semibold mb-6 text-ck-coral">Mesaj Gönderin</h2>
            <form className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-ck-dark-text">Adınız Soyadınız</label>
                <input type="text" name="name" id="name" className="mt-1 block w-full px-3 py-2 border border-ck-light-gray rounded-md shadow-sm focus:ring-ck-coral focus:border-ck-coral sm:text-sm" />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-ck-dark-text">E-posta Adresiniz</label>
                <input type="email" name="email" id="email" className="mt-1 block w-full px-3 py-2 border border-ck-light-gray rounded-md shadow-sm focus:ring-ck-coral focus:border-ck-coral sm:text-sm" />
              </div>
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-ck-dark-text">Konu</label>
                <input type="text" name="subject" id="subject" className="mt-1 block w-full px-3 py-2 border border-ck-light-gray rounded-md shadow-sm focus:ring-ck-coral focus:border-ck-coral sm:text-sm" />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-ck-dark-text">Mesajınız</label>
                <textarea id="message" name="message" rows={4} className="mt-1 block w-full px-3 py-2 border border-ck-light-gray rounded-md shadow-sm focus:ring-ck-coral focus:border-ck-coral sm:text-sm"></textarea>
              </div>
              <div>
                <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-ck-coral hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-ck-coral transition-colors">
                  Gönder
                </button>
              </div>
            </form>
          </motion.div>

          {/* Contact Details Section */}
          <motion.div 
            className="bg-white/80 backdrop-blur-md p-8 rounded-xl shadow-2xl space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <div>
              <h2 className="text-2xl font-semibold mb-4 text-ck-coral">İletişim Bilgilerimiz</h2>
              <div className="flex items-center mb-3">
                <FaMapMarkerAlt className="text-ck-coral mr-3 text-xl" />
                <p className="text-ck-dark-text/90">CK Medya Merkezi, İnovasyon Caddesi No:123, Kat:4, Daire:5, Şişli/İstanbul</p>
              </div>
              <div className="flex items-center mb-3">
                <FaPhone className="text-ck-coral mr-3 text-xl" />
                <p className="text-ck-dark-text/90">+90 212 555 66 77</p>
              </div>
              <div className="flex items-center mb-3">
                <FaEnvelope className="text-ck-coral mr-3 text-xl" />
                <p className="text-ck-dark-text/90">info@ckmedya.com.tr</p>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-3 text-ck-coral">Çalışma Saatlerimiz</h3>
              <p className="text-ck-dark-text/90">Pazartesi - Cuma: 09:00 - 18:00</p>
              <p className="text-ck-dark-text/90">Hafta Sonu: Kapalı</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-3 text-ck-coral">Sosyal Medyada Bizi Takip Edin</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-ck-coral hover:text-opacity-70 transition-colors text-2xl"><FaFacebook /></a>
                <a href="#" className="text-ck-coral hover:text-opacity-70 transition-colors text-2xl"><FaTwitter /></a>
                <a href="#" className="text-ck-coral hover:text-opacity-70 transition-colors text-2xl"><FaInstagram /></a>
                <a href="#" className="text-ck-coral hover:text-opacity-70 transition-colors text-2xl"><FaLinkedinIn /></a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;

