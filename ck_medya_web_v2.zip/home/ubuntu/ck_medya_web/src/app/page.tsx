import Link from 'next/link';
import { motion } from 'framer-motion';
import { FiChevronRight, FiUsers, FiTrendingUp, FiMessageSquare, FiEdit3, FiAward, FiStar, FiPlayCircle, FiEye } from 'react-icons/fi'; // Added more icons

// Animation variants (can be imported from a shared file)
const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.8, ease: "easeOut" } },
};

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.1,
    },
  },
};

const cardHover = {
  hover: { 
    y: -8,
    boxShadow: "0px 15px 30px rgba(0,0,0,0.12)",
    transition: { type: "spring", stiffness: 200, damping: 15 }
  }
};

const iconVariants = {
  hover: { scale: 1.1, rotate: 5, transition: { type: "spring", stiffness: 300 } }
};

export default function HomePage() {
  const services = [
    {
      title: "Influencer Marketing",
      description: "Markanızın mesajını, hedef kitlenizin güvendiği etkileyici isimlerle buluşturuyoruz.",
      icon: <FiUsers className="w-10 h-10 mb-4 text-ck-coral" />,
      link: "/hizmetlerimiz#influencer-marketing"
    },
    {
      title: "Sosyal Medya Yönetimi",
      description: "Markanızın kimliğine uygun, yaratıcı ve sonuç odaklı sosyal medya stratejileri geliştiriyoruz.",
      icon: <FiTrendingUp className="w-10 h-10 mb-4 text-ck-coral" />,
      link: "/hizmetlerimiz#sosyal-medya"
    },
    {
      title: "Dijital PR & İtibar",
      description: "Dijital dünyada markanız hakkında konuşulanları yönetiyor, olumlu bir algı oluşturuyoruz.",
      icon: <FiMessageSquare className="w-10 h-10 mb-4 text-ck-coral" />,
      link: "/hizmetlerimiz#dijital-pr"
    },
    {
      title: "Kreatif İçerik Üretimi",
      description: "Hedef kitlenizin ilgisini çekecek, onları bilgilendirecek ve harekete geçirecek özgün içerikler.",
      icon: <FiEdit3 className="w-10 h-10 mb-4 text-ck-coral" />,
      link: "/hizmetlerimiz#icerik-uretimi"
    }
  ];

  const whyUsPoints = [
    { title: "Stratejik Yaklaşım", description: "Size özel, veriye dayalı stratejiler geliştirir, yaratıcı kampanyalarla hayata geçiririz.", icon: <FiAward className="w-8 h-8 text-ck-lavender" /> },
    { title: "Şeffaflık ve Güven", description: "İş ortaklığımızın temelini şeffaflık ve güven oluşturur. Sürecin her aşamasında sizi bilgilendiririz.", icon: <FiEye className="w-8 h-8 text-ck-lavender" /> },
    { title: "Sonuç Odaklılık", description: "Net hedefler belirler, bu hedeflere ulaşmak için titizlikle çalışır ve başarıyı rakamlarla kanıtlarız.", icon: <FiTrendingUp className="w-8 h-8 text-ck-lavender" /> },
    { title: "Dinamik Uzman Ekip", description: "Alanında deneyimli, genç, dinamik ve sürekli öğrenmeye açık bir ekibe sahibiz.", icon: <FiUsers className="w-8 h-8 text-ck-lavender" /> },
  ];

  return (
    <div className="space-y-20 md:space-y-32 pb-20 overflow-x-hidden">
      {/* Hero Section */}
      <motion.section 
        className="relative text-center py-28 md:py-40 px-4 overflow-hidden bg-gradient-to-br from-ck-pale-blue via-ck-lavender to-ck-mint-green rounded-b-3xl md:rounded-b-[50px] shadow-xl"
        variants={fadeIn}
        initial="hidden"
        animate="visible"
      >
        <motion.div 
          className="absolute inset-0 opacity-20"
          // Example subtle animated pattern
        >
          {/* Add subtle animated background elements here if desired */}
        </motion.div>

        <motion.div className="relative z-10 container mx-auto" variants={staggerContainer}>
          <motion.h1 
            className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-extrabold mb-6 text-ck-dark-text drop-shadow-lg"
            variants={fadeInUp}
          >
            CK Medya
          </motion.h1>
          <motion.p 
            className="text-2xl sm:text-3xl md:text-4xl font-light mb-10 max-w-4xl mx-auto text-ck-dark-text/80 drop-shadow-sm"
            variants={fadeInUp}
          >
            Dijital Dünyada Markanızın <span className="text-ck-coral font-semibold">Parlayan Yıldızı!</span>
          </motion.p>
          <motion.p 
            className="text-lg md:text-xl mb-12 max-w-2xl mx-auto text-ck-dark-text/70"
            variants={fadeInUp}
          >
            Yaratıcı stratejiler, yenilikçi çözümler ve uzman ekibimizle markanızın potansiyelini açığa çıkarıyoruz. Sınırları zorlayan fikirlerle dijitalde fark yaratın.
          </motion.p>
          <motion.div variants={fadeInUp}>
            <Link 
              href="/hizmetlerimiz"
              className="bg-ck-coral text-ck-white font-bold py-4 px-10 rounded-lg hover:bg-opacity-80 transition-all duration-300 text-lg shadow-lg hover:shadow-xl transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-ck-coral/50"
            >
              Hizmetlerimizi Keşfedin
            </Link>
          </motion.div>
        </motion.div>
      </motion.section>

      {/* Services Overview */}
      <motion.section 
        className="container mx-auto px-4 py-16"
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold text-center mb-4 text-ck-dark-text"
          variants={fadeInUp}
        >
          Hizmetlerimizle Tanışın
        </motion.h2>
        <motion.p 
          className="text-center text-ck-dark-text/70 mb-12 md:mb-16 max-w-2xl mx-auto"
          variants={fadeInUp}
        >
          Markanızın ihtiyaç duyduğu her alanda, ölçülebilir sonuçlar ve kalıcı başarılar sunan kapsamlı hizmetlerimizle dijital dünyada fark yaratın.
        </motion.p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div 
              key={index} 
              className="bg-ck-white p-6 md:p-8 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col items-center text-center border border-ck-light-gray/50"
              variants={fadeInUp}
              whileHover={cardHover}
            >
              {service.icon}
              <h3 className="text-xl md:text-2xl font-semibold mb-3 text-ck-dark-text">{service.title}</h3>
              <p className="text-ck-dark-text/70 text-sm mb-6 flex-grow">{service.description}</p>
              <Link 
                href={service.link} 
                className="mt-auto text-ck-coral hover:text-opacity-80 font-semibold inline-flex items-center group"
              >
                Daha Fazla Bilgi <FiChevronRight className="ml-1 group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Why CK Medya */}
      <motion.section 
        className="py-16 md:py-20 bg-gradient-to-b from-ck-light-gray/30 to-transparent"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={staggerContainer}
      >
        <div className="container mx-auto px-4">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-center mb-4 text-ck-dark-text"
            variants={fadeInUp}
          >
            Neden <span className="text-ck-coral">CK Medya</span>?
          </motion.h2>
          <motion.p 
            className="text-center text-ck-dark-text/70 mb-12 md:mb-16 max-w-2xl mx-auto"
            variants={fadeInUp}
          >
            Çünkü biz, sıradan bir ajanstan çok daha fazlasıyız. Sizin başarınızı kendi başarımız olarak görüyor, tutkuyla ve yenilikçi bir bakış açısıyla çalışıyoruz.
          </motion.p>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {whyUsPoints.map((point, index) => (
              <motion.div 
                key={index} 
                className="bg-ck-white p-6 rounded-xl shadow-lg flex items-start space-x-4 hover:shadow-xl transition-shadow duration-300 border border-ck-light-gray/50"
                variants={fadeInUp}
                whileHover={{ y: -5 }}
              >
                <div className="flex-shrink-0 bg-ck-coral/10 p-3 rounded-full">
                  {point.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-1 text-ck-dark-text">{point.title}</h3>
                  <p className="text-ck-dark-text/70 text-sm leading-relaxed">{point.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Testimonials Snippet */}
      <motion.section 
        className="container mx-auto px-4 py-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={staggerContainer}
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold text-center mb-4 text-ck-dark-text"
          variants={fadeInUp}
        >
          Başarı Hikayelerimizden Kesitler
        </motion.h2>
        <motion.p 
          className="text-center text-ck-dark-text/70 mb-12 md:mb-16 max-w-2xl mx-auto"
          variants={fadeInUp}
        >
          Müşterilerimizin memnuniyeti ve projelerimizde elde ettiğimiz somut sonuçlar, en büyük gurur kaynağımız.
        </motion.p>
        {/* Placeholder for actual testimonials - design concept */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {[1, 2].map(i => (
            <motion.div 
              key={i} 
              className="bg-ck-white p-8 rounded-xl shadow-lg border border-ck-light-gray/50"
              variants={fadeInUp}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, s) => <FiStar key={s} className={`w-5 h-5 ${s < (i === 1 ? 5 : 4) ? 'text-ck-bright-yellow' : 'text-ck-medium-gray/50'}`} />)}
              </div>
              <p className="text-ck-dark-text/80 italic mb-6 leading-relaxed">
                "CK Medya ile çalışmak harikaydı! Projemize getirdikleri yaratıcı bakış açısı ve profesyonellikleri sayesinde hedeflerimize ulaştık. Kesinlikle tavsiye ederim."
              </p>
              <div className="flex items-center">
                <img src={`/avatar-placeholder${i}.png`} alt={`Müşteri ${i}`} className="w-12 h-12 rounded-full mr-4 object-cover bg-ck-light-gray"/>
                <div>
                  <p className="font-semibold text-ck-dark-text">Müşteri Adı {i}</p>
                  <p className="text-sm text-ck-dark-text/70">Şirket Adı, Pozisyon</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        <motion.div className="text-center mt-12" variants={fadeInUp}>
          <Link href="/referanslar" 
            className="text-ck-coral hover:text-opacity-80 font-semibold inline-flex items-center group text-lg"
          >
            Tüm Referansları Gör <FiChevronRight className="ml-1 group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>
      </motion.section>

      {/* Blog Snippet */}
      <motion.section 
        className="py-16 md:py-20 bg-gradient-to-tr from-ck-mint-green/50 to-ck-pale-blue/50"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={staggerContainer}
      >
        <div className="container mx-auto px-4">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-center mb-4 text-ck-dark-text"
            variants={fadeInUp}
          >
            Güncel Blog Yazıları
          </motion.h2>
          <motion.p 
            className="text-center text-ck-dark-text/70 mb-12 md:mb-16 max-w-2xl mx-auto"
            variants={fadeInUp}
          >
            Dijital pazarlama, iletişim stratejileri ve daha birçok konuda en güncel bilgileri, uzman analizlerini blogumuzda bulabilirsiniz.
          </motion.p>
          {/* Placeholder for actual blog posts - design concept */}
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map(i => (
              <motion.div 
                key={i} 
                className="bg-ck-white rounded-xl shadow-lg overflow-hidden group border border-ck-light-gray/50"
                variants={fadeInUp}
                whileHover={{ y: -5, transition: { type: "spring", stiffness: 300 } }}
              >
                <Link href={`/blog/placeholder-slug-${i}`} className="block h-52 w-full overflow-hidden">
                  <img src={`/placeholder-blog${i}.jpg`} alt={`Blog Post ${i}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-in-out bg-ck-light-gray"/>
                </Link>
                <div className="p-6">
                  <p className="text-xs text-ck-dark-text/60 mb-1">10 Mayıs 2025 • Kategori</p>
                  <h3 className="text-lg font-semibold mb-2 text-ck-dark-text hover:text-ck-coral transition-colors">
                    <Link href={`/blog/placeholder-slug-${i}`}>Blog Başlığı Örneği {i}</Link>
                  </h3>
                  <p className="text-sm text-ck-dark-text/70 mb-4 line-clamp-3">Kısa bir blog özeti buraya gelecek. Bu, makalenin ne hakkında olduğuna dair bir fikir verecektir...</p>
                  <Link href={`/blog/placeholder-slug-${i}`} className="text-ck-coral hover:text-opacity-80 font-semibold inline-flex items-center group-hover:text-ck-coral/80">
                    Devamını Oku <FiChevronRight className="ml-1 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
          <motion.div className="text-center mt-12" variants={fadeInUp}>
            <Link href="/blog" 
              className="text-ck-coral hover:text-opacity-80 font-semibold inline-flex items-center group text-lg"
            >
              Tüm Yazıları Oku <FiChevronRight className="ml-1 group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>
        </div>
      </motion.section>

      {/* Call to Action Section */}
      <motion.section 
        className="container mx-auto py-16 md:py-20 px-6 md:px-8 bg-gradient-to-r from-ck-coral to-ck-bright-yellow text-ck-white rounded-2xl shadow-xl text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        variants={fadeIn}
      >
        <motion.h2 
          className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 drop-shadow-md"
          variants={fadeInUp}
        >
          Markanız İçin Neler Yapabileceğimizi Konuşalım mı?
        </motion.h2>
        <motion.p 
          className="text-lg md:text-xl mb-10 max-w-2xl mx-auto opacity-90"
          variants={fadeInUp}
        >
          Aklınızdaki projeyi, hedeflerinizi veya sadece bir merhaba demek için aşağıdaki formu doldurabilir ya da tek tıkla WhatsApp üzerinden bize ulaşabilirsiniz.
        </motion.p>
        <motion.div 
          className="flex flex-col sm:flex-row justify-center items-center gap-4 md:gap-6"
          variants={fadeInUp}
        >
          <Link 
            href="/iletisim#form" 
            className="bg-ck-white text-ck-coral font-bold py-3 px-8 rounded-lg hover:bg-opacity-95 transition-all duration-300 text-lg shadow-md hover:shadow-lg transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-white/50"
          >
            İletişim Formu
          </Link>
          <a 
            href="https://wa.me/905551234567" // Placeholder number
            target="_blank" 
            rel="noopener noreferrer" 
            className="bg-green-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-green-600 transition-all duration-300 text-lg shadow-md hover:shadow-lg transform hover:scale-105 flex items-center gap-2 focus:outline-none focus:ring-4 focus:ring-green-500/50"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" className="w-5 h-5 fill-current"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 .3c87.9 0 159.1 71.2 159.1 159.1 0 46.2-19.9 88.4-53.3 118.4L384 400l-86.4-22.6c-30.3 16.4-64.3 25.1-99.9 25.1-87.9 0-159.1-71.2-159.1-159.1S136 97.4 223.9 97.4zM338.3 325.2c-4.5-2.3-26.6-13.1-30.7-14.6-4.1-1.5-7.1-2.3-10.1 2.3-3 4.5-11.6 14.6-14.2 17.6-2.6 3-5.2 3.4-9.7 1.1-4.5-2.3-18.9-7-36-22.2-13.3-11.7-22.4-26.2-25.1-30.7-2.6-4.5-.3-7.1 2-9.4 2.1-2.1 4.5-5.6 6.8-8.4 2.3-2.8 3-4.5 4.5-7.5 1.5-3 0-5.6-1.1-7.5-1.1-1.9-10.1-24.2-13.8-33.2-3.7-9-7.4-7.8-10.1-7.8h-9.1c-3 0-7.5 1.1-11.6 5.6-4.1 4.5-15.7 15.4-15.7 37.5 0 22.1 16 43.4 18.3 46.2 2.3 2.8 31.4 48.4 76.2 67.6 10.6 4.5 18.9 7.2 25.4 9.2 11.7 3.6 22.4 3 30.7 1.8 9.7-1.4 29.3-12 33.2-23.5 3.9-11.5 3.9-21.4 2.8-23.5-.9-2.2-3.9-3.6-8.4-5.9z"/></svg>
            WhatsApp ile Ulaşın
          </a>
        </motion.div>
         <p className="text-center text-xs mt-8 opacity-80">*WhatsApp numarası örnektir.</p>
      </motion.section>
    </div>
  );
}

