import Link from 'next/link';
import { motion } from 'framer-motion';
import { FiChevronRight } from 'react-icons/fi'; // Example icon

export const metadata = {
  title: 'Hizmetlerimiz - CK Medya İletişim Menajerlik',
  description: 'CK Medya olarak sunduğumuz kapsamlı dijital pazarlama ve iletişim hizmetlerini keşfedin: Influencer marketing, sosyal medya yönetimi, dijital PR, içerik üretimi ve marka danışmanlığı.',
};

// Animation variants
const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.8 } },
};

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const cardHover = {
  hover: { 
    scale: 1.03,
    boxShadow: "0px 10px 20px rgba(0,0,0,0.1)",
    transition: { type: "spring", stiffness: 300 }
  }
};

const HizmetlerimizPage = () => {
  const services = [
    {
      id: 1,
      title: "Influencer Marketing & Fenomen İletişimi",
      description: "Markanızın mesajını doğru hedef kitleye, en etkili ve organik şekilde ulaştırmak için kapsamlı influencer marketing stratejileri geliştiriyoruz. Markanızın değerleriyle örtüşen, hedef kitlenizle gerçek bir bağ kurmuş influencer'ları titizlikle seçiyoruz.",
      shortDescription: "Hedef kitlenizin güvendiği isimlerle markanızın hikayesini anlatın, etkileşimi ve bilinirliği artırın.",
      icon: "🎯", // Placeholder icon
      benefits: [
        "Marka bilinirliğinde ve görünürlüğünde artış.",
        "Hedef kitleye doğrudan ve etkili erişim.",
        "Güvenilirlik ve marka imajında güçlenme.",
        "Sosyal medya etkileşimlerinde ve takipçi sayısında artış.",
        "Web sitesi trafiğinde ve potansiyel müşteri dönüşümlerinde yükseliş.",
        "Ölçülebilir ve şeffaf kampanya sonuçları."
      ],
      cta: "Strateji Oluşturalım",
      ctaLink: "/iletisim?subject=Influencer+Marketing+Talebi"
    },
    {
      id: 2,
      title: "Stratejik Sosyal Medya Yönetimi",
      description: "Markanızın sosyal medyadaki varlığını sıradanlıktan çıkarıp, onu bir cazibe merkezine dönüştürüyoruz. Markanızın hedeflerine, hedef kitlesine ve rekabet ortamına uygun, özgün ve yaratıcı bir sosyal medya stratejisi oluşturuyoruz.",
      shortDescription: "Markanızın kimliğine uygun, yaratıcı ve sonuç odaklı sosyal medya stratejileriyle topluluğunuzu büyütün.",
      icon: "📱", // Placeholder icon
      benefits: [
        "Güçlü ve tutarlı bir marka imajı.",
        "Artan marka bilinirliği ve erişimi.",
        "Hedef kitleyle derinlemesine etkileşim ve sadakat.",
        "Web sitesi trafiğinde ve dönüşüm oranlarında artış.",
        "Rakipler arasında fark yaratan bir sosyal medya varlığı.",
        "Detaylı performans raporları ve sürekli optimizasyon."
      ],
      cta: "Sosyal Medyanızı Güçlendirelim",
      ctaLink: "/iletisim?subject=Sosyal+Medya+Yonetimi+Talebi"
    },
    {
      id: 3,
      title: "Dijital PR ve İtibar Yönetimi",
      description: "Markanızın dijital dünyadaki itibarını proaktif bir şekilde yönetiyor, olumlu bir algı oluşturuyor ve bu algıyı korumak için stratejik adımlar atıyoruz. Online medya ilişkileri ve kriz iletişimi stratejileri geliştiriyoruz.",
      shortDescription: "Dijital dünyada markanızın itibarını koruyun, olumlu algı oluşturun ve krizleri etkin yönetin.",
      icon: "🛡️", // Placeholder icon
      benefits: [
        "Güçlü ve pozitif bir marka itibarı.",
        "Artan medya görünürlüğü ve güvenilirlik.",
        "Krizlere karşı hazırlıklı olma ve etkin kriz yönetimi.",
        "Hedef kitle ve paydaşlar nezdinde artan saygınlık.",
        "Marka değerinin korunması ve artırılması."
      ],
      cta: "İtibarınızı Yönetelim",
      ctaLink: "/iletisim?subject=Dijital+PR+Talebi"
    },
    {
      id: 4,
      title: "Kreatif İçerik Üretimi ve Pazarlaması",
      description: "Markanızın hikayesini en çarpıcı şekilde anlatan, hedef kitlenizin dikkatini çeken ve onları harekete geçiren yaratıcı içerikler üretiyoruz. Blog yazıları, videolar, infografikler ve daha fazlası.",
      shortDescription: "Hedef kitlenizin ilgisini çekecek, bilgilendirecek ve harekete geçirecek özgün içerikler üretin.",
      icon: "✍️", // Placeholder icon
      benefits: [
        "Hedef kitlenizle rezonansa giren, özgün ve değerli içerikler.",
        "Arama motorlarında daha iyi sıralamalar ve artan organik trafik.",
        "Marka otoritesi ve düşünce liderliği.",
        "Artan kullanıcı etkileşimi ve paylaşımı.",
        "Dönüşüm oranlarında iyileşme."
      ],
      cta: "İçerik Stratejisi Geliştirelim",
      ctaLink: "/iletisim?subject=Icerik+Uretimi+Talebi"
    },
    {
      id: 5,
      title: "Marka Danışmanlığı ve Konumlandırma",
      description: "Markanızın özünü anlamak, onu rakiplerinden ayrıştıran benzersiz değerlerini ortaya çıkarmak ve pazarda unutulmaz bir iz bırakmasını sağlamak için kapsamlı marka danışmanlığı hizmetleri sunuyoruz.",
      shortDescription: "Markanızın pazardaki yerini sağlamlaştırın, benzersiz değerlerinizi ortaya çıkarın ve güçlü bir kimlik oluşturun.",
      icon: "💡", // Placeholder icon
      benefits: [
        "Net ve güçlü bir marka kimliği ve konumlandırması.",
        "Rakiplerden ayrışan benzersiz bir marka değeri.",
        "Hedef kitleyle daha derin ve anlamlı bir bağ.",
        "Tutarlı ve etkili bir pazarlama iletişimi.",
        "Uzun vadeli marka sadakati ve büyüme."
      ],
      cta: "Markanızı Konumlandıralım",
      ctaLink: "/iletisim?subject=Marka+Danismanligi+Talebi"
    }
  ];

  return (
    <div className="space-y-16 md:space-y-24 pb-16">
      <motion.section 
        className="text-center py-16 md:py-20 px-4 bg-gradient-to-br from-ck-pale-blue via-ck-lavender to-ck-mint-green rounded-xl shadow-xl"
        variants={fadeIn}
        initial="hidden"
        animate="visible"
      >
        <motion.h1 
          className="text-4xl md:text-6xl font-bold mb-6 text-ck-dark-text drop-shadow-sm"
          variants={fadeInUp}
        >
          Hizmetlerimiz
        </motion.h1>
        <motion.p 
          className="text-lg md:text-xl text-ck-dark-text/80 max-w-3xl mx-auto"
          variants={fadeInUp}
        >
          CK Medya olarak, markanızın dijital dünyadaki tüm ihtiyaçlarına cevap veren, yenilikçi ve sonuç odaklı hizmetler sunuyoruz. Stratejik düşünceyi yaratıcı uygulamalarla birleştirerek, hedeflerinize ulaşmanızı sağlıyoruz.
        </motion.p>
      </motion.section>

      <motion.div 
        className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
      >
        {services.map((service) => (
          <motion.div 
            key={service.id} 
            className="bg-ck-white rounded-xl shadow-lg overflow-hidden flex flex-col hover:shadow-2xl transition-all duration-300 border border-ck-light-gray/50"
            variants={fadeInUp}
            whileHover={{ scale: 1.02, transition: { type: "spring", stiffness: 400, damping: 10 } }}
          >
            <div className="p-6 md:p-8 flex-grow">
              <div className="text-4xl mb-4 text-ck-coral">{service.icon}</div>
              <h2 className="text-2xl font-bold mb-3 text-ck-dark-text">{service.title}</h2>
              <p className="text-ck-dark-text/70 text-sm mb-6 leading-relaxed">
                {service.shortDescription}
              </p>
            </div>
            <div className="p-6 md:p-8 bg-ck-light-gray/50 border-t border-ck-light-gray/50">
              <Link 
                href={service.ctaLink} 
                className="inline-flex items-center justify-center w-full bg-ck-coral text-ck-white font-semibold py-3 px-6 rounded-lg hover:bg-opacity-90 transition duration-300 shadow-md hover:shadow-lg transform hover:scale-105 text-center"
              >
                {service.cta} <FiChevronRight className="ml-2" />
              </Link>
            </div>
            {/* Optional: Expandable benefits section - for future enhancement if needed */}
            {/* <div className="p-6 border-t border-ck-light-gray/30">
              <h3 className="text-md font-semibold mb-2 text-ck-dark-text">Faydaları:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-ck-dark-text/60">
                {service.benefits.slice(0, 3).map((benefit, index) => (
                  <li key={index}>{benefit}</li>
                ))}
              </ul>
            </div> */}
          </motion.div>
        ))}
      </motion.div>

      <motion.section 
        className="container mx-auto mt-16 md:mt-24 py-12 md:py-16 px-6 md:px-8 bg-gradient-to-r from-ck-coral to-ck-bright-yellow text-ck-white rounded-xl shadow-xl text-center"
        variants={fadeIn}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold mb-4"
          variants={fadeInUp}
        >
          Markanız İçin En İyisi Burada!
        </motion.h2>
        <motion.p 
          className="text-lg md:text-xl mb-8 max-w-2xl mx-auto opacity-90"
          variants={fadeInUp}
        >
          CK Medya olarak, sunduğumuz her hizmette mükemmelliği hedefler, markanızın başarısı için tutkuyla çalışırız. Projelerinizi görüşmek veya size özel bir strateji oluşturmak için hemen bizimle iletişime geçin.
        </motion.p>
        <motion.div 
          className="flex flex-col sm:flex-row justify-center items-center gap-4"
          variants={fadeInUp}
        >
            <Link 
              href="/iletisim#form" 
              className="bg-ck-white text-ck-coral font-bold py-3 px-8 rounded-lg hover:bg-opacity-95 transition duration-300 text-lg shadow-md hover:shadow-lg transform hover:scale-105"
            >
                İletişim Formu
            </Link>
            <a 
              href="https://wa.me/905321234567" // Placeholder number
              target="_blank" 
              rel="noopener noreferrer" 
              className="bg-green-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-green-600 transition duration-300 text-lg shadow-md hover:shadow-lg transform hover:scale-105 flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" className="w-5 h-5 fill-current"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 .3c87.9 0 159.1 71.2 159.1 159.1 0 46.2-19.9 88.4-53.3 118.4L384 400l-86.4-22.6c-30.3 16.4-64.3 25.1-99.9 25.1-87.9 0-159.1-71.2-159.1-159.1S136 97.4 223.9 97.4zM338.3 325.2c-4.5-2.3-26.6-13.1-30.7-14.6-4.1-1.5-7.1-2.3-10.1 2.3-3 4.5-11.6 14.6-14.2 17.6-2.6 3-5.2 3.4-9.7 1.1-4.5-2.3-18.9-7-36-22.2-13.3-11.7-22.4-26.2-25.1-30.7-2.6-4.5-.3-7.1 2-9.4 2.1-2.1 4.5-5.6 6.8-8.4 2.3-2.8 3-4.5 4.5-7.5 1.5-3 0-5.6-1.1-7.5-1.1-1.9-10.1-24.2-13.8-33.2-3.7-9-7.4-7.8-10.1-7.8h-9.1c-3 0-7.5 1.1-11.6 5.6-4.1 4.5-15.7 15.4-15.7 37.5 0 22.1 16 43.4 18.3 46.2 2.3 2.8 31.4 48.4 76.2 67.6 10.6 4.5 18.9 7.2 25.4 9.2 11.7 3.6 22.4 3 30.7 1.8 9.7-1.4 29.3-12 33.2-23.5 3.9-11.5 3.9-21.4 2.8-23.5-.9-2.2-3.9-3.6-8.4-5.9z"/></svg>
              WhatsApp ile Ulaşın
            </a>
        </motion.div>
        <p className="text-center text-xs mt-6 opacity-80">*WhatsApp numarası örnektir.</p>
      </motion.section>
    </div>
  );
};

export default HizmetlerimizPage;

