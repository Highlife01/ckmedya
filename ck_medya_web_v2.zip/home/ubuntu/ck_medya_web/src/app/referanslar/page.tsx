import Link from 'next/link';
import { motion } from 'framer-motion';
import { FaQuoteLeft, FaStar } from 'react-icons/fa'; // Example icons

export const metadata = {
  title: 'Referanslarımız - CK Medya İletişim Menajerlik',
  description: 'CK Medya olarak çalıştığımız markalar ve başarı hikayelerimiz. Müşteri yorumları ve tamamladığımız projelerden örnekler.',
};

// Animation variants (can be imported from a shared file if used across multiple pages)
const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.8 } },
};

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const ReferanslarPage = () => {
  const projects = [
    {
      id: 1,
      title: "Global Teknoloji Markası Lansmanı",
      description: "Yeni nesil bir teknoloji ürününün Türkiye pazarına giriş stratejisini oluşturduk ve kapsamlı bir influencer marketing kampanyası yürüttük. Sonuç: %300 ROI ve pazar payında %15 artış.",
      image: "/placeholder-project1.jpg", 
      category: "Influencer Marketing",
      clientLogo: "/client-logo-placeholder1.png"
    },
    {
      id: 2,
      title: "E-Ticaret Devi Sosyal Medya Dönüşümü",
      description: "Lider bir e-ticaret platformunun sosyal medya kanallarını yeniden yapılandırarak etkileşimi %150, web sitesi trafiğini ise %80 artırdık.",
      image: "/placeholder-project2.jpg",
      category: "Sosyal Medya Yönetimi",
      clientLogo: "/client-logo-placeholder2.png"
    },
    {
      id: 3,
      title: "Finans Sektörü İtibar Yönetimi",
      description: "Önde gelen bir finans kuruluşunun dijital itibarını güçlendirdik ve kriz iletişimi süreçlerini başarıyla yönettik.",
      image: "/placeholder-project3.jpg",
      category: "Dijital PR",
      clientLogo: "/client-logo-placeholder3.png"
    },
     {
      id: 4,
      title: "Moda Markası İçerik Stratejisi",
      description: "Genç bir moda markası için hedef kitleye yönelik özgün ve etkileyici içerikler üreterek marka bilinirliğini ve sadakatini artırdık.",
      image: "/placeholder-project4.jpg",
      category: "Kreatif İçerik",
      clientLogo: "/client-logo-placeholder4.png"
    }
  ];

  const testimonials = [
    {
      id: 1,
      name: "Elif Aydın",
      company: "TechGlobal Türkiye, Pazarlama Müdürü",
      comment: "CK Medya ekibi, projemizi kendi projeleri gibi sahiplendi ve beklentilerimizin çok üzerinde sonuçlar elde etmemizi sağladı. Özellikle doğru influencer seçimi ve yaratıcı kampanya kurgusu konusundaki uzmanlıkları takdire şayan.",
      avatar: "/avatar-placeholder1.png",
      rating: 5
    },
    {
      id: 2,
      name: "Can Vural",
      company: "ShopFast, CEO",
      comment: "Sosyal medya yönetimi konusunda uzun süredir aradığımız partneri CK Medya\'da bulduk. Markamızın dilini çok iyi anladılar ve hedef kitlemizle mükemmel bir iletişim kurmamızı sağladılar. Satışlarımızda gözle görülür bir artış yaşadık.",
      avatar: "/avatar-placeholder2.png",
      rating: 5
    },
    {
      id: 3,
      name: "Zeynep Ersoy",
      company: "FinanceTrust, Kurumsal İletişim Direktörü",
      comment: "İtibar yönetimi gibi hassas bir konuda CK Medya\'ya güvendik ve asla pişman olmadık. Kriz anlarında bile soğukkanlı ve stratejik yaklaşımlarıyla markamızı koruma altına aldılar. Profesyonellikleri ve hızlı aksiyon almaları harika.",
      avatar: "/avatar-placeholder3.png",
      rating: 4
    }
  ];

  return (
    <div className="space-y-16 md:space-y-24 pb-16">
      <motion.section 
        className="text-center py-16 md:py-20 px-4 bg-gradient-to-br from-ck-pale-blue via-ck-lavender to-ck-mint-green rounded-xl shadow-xl"
        variants={fadeIn}
        initial="hidden"
        animate="visible"
      >
        <motion.h1 
          className="text-4xl md:text-6xl font-bold mb-6 text-ck-dark-text drop-shadow-sm"
          variants={fadeInUp}
        >
          Referanslarımız ve Başarı Hikayelerimiz
        </motion.h1>
        <motion.p 
          className="text-lg md:text-xl text-ck-dark-text/80 max-w-3xl mx-auto"
          variants={fadeInUp}
        >
          CK Medya olarak, en büyük referansımız, birlikte çalıştığımız markaların elde ettiği somut başarılar ve yüzlerindeki memnuniyettir. Markanızın hedeflerine ulaşması için çıktığımız ortak yolculuklardan bazılarını keşfedin.
        </motion.p>
      </motion.section>

      <motion.section 
        className="container mx-auto px-4"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 md:mb-16 text-ck-dark-text">Örnek Projelerimiz</h2>
        <div className="grid md:grid-cols-2 gap-8 md:gap-10">
          {projects.map((project) => (
            <motion.div 
              key={project.id} 
              className="bg-ck-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 border border-ck-light-gray/50 group"
              variants={fadeInUp}
              whileHover={{ y: -5, transition: { type: "spring", stiffness: 300 } }}
            >
              <div className="relative h-56 md:h-64 w-full overflow-hidden">
                <img 
                  src={project.image || "/placeholder-image.png"} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-in-out"
                />
                <div className="absolute top-4 right-4 bg-ck-coral text-ck-white text-xs font-semibold px-3 py-1 rounded-full shadow-md">
                  {project.category}
                </div>
              </div>
              <div className="p-6 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold mb-3 text-ck-dark-text">{project.title}</h3>
                <p className="text-ck-dark-text/70 text-sm mb-4 leading-relaxed">{project.description}</p>
                {project.clientLogo && (
                  <div className="mt-4 mb-2">
                    <img src={project.clientLogo} alt={`${project.title} - Client`} className="h-8 opacity-70" />
                  </div>
                )}
                {/* <Link href={`/referanslar/${project.id}`} className="text-ck-coral hover:text-opacity-80 font-semibold inline-flex items-center">
                  Proje Detayı <FaChevronRight className="ml-1 text-xs" />
                </Link> */}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>

      <motion.section 
        className="container mx-auto px-4 mt-16 md:mt-24"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 md:mb-16 text-ck-dark-text">Müşterilerimiz Ne Diyor?</h2>
        <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10">
          {testimonials.map((testimonial) => (
            <motion.div 
              key={testimonial.id} 
              className="bg-ck-light-gray/70 p-6 md:p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col"
              variants={fadeInUp}
            >
              <FaQuoteLeft className="text-ck-coral text-3xl mb-4 opacity-80" />
              <p className="text-ck-dark-text/80 italic mb-6 leading-relaxed flex-grow">"{testimonial.comment}"</p>
              <div className="flex items-center mt-auto pt-4 border-t border-ck-medium-gray/30">
                <img src={testimonial.avatar || "/avatar-placeholder.png"} alt={testimonial.name} className="w-12 h-12 rounded-full mr-4 object-cover"/>
                <div>
                  <p className="font-bold text-ck-dark-text">- {testimonial.name}</p>
                  <p className="text-sm text-ck-dark-text/70">{testimonial.company}</p>
                  {testimonial.rating && (
                    <div className="flex mt-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <FaStar key={i} className="text-ck-bright-yellow" />
                      ))}
                      {[...Array(5 - testimonial.rating)].map((_, i) => (
                        <FaStar key={i} className="text-ck-medium-gray/50" />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>

      <motion.section 
        className="container mx-auto mt-16 md:mt-24 py-12 md:py-16 px-6 md:px-8 bg-gradient-to-r from-ck-coral to-ck-bright-yellow text-ck-white rounded-xl shadow-xl text-center"
        variants={fadeIn}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold mb-4"
          variants={fadeInUp}
        >
          Sizin Markanız İçin de Harikalar Yaratabiliriz!
        </motion.h2>
        <motion.p 
          className="text-lg md:text-xl mb-8 max-w-2xl mx-auto opacity-90"
          variants={fadeInUp}
        >
          CK Medya olarak, sunduğumuz her hizmette mükemmelliği hedefler, markanızın başarısı için tutkuyla çalışırız. Dijital dünyada markanızın parlaması için ihtiyacınız olan tüm çözümler burada!
        </motion.p>
        <motion.div variants={fadeInUp}>
          <Link 
            href="/iletisim#form" 
            className="bg-ck-white text-ck-coral font-bold py-3 px-8 rounded-lg hover:bg-opacity-95 transition duration-300 text-lg shadow-md hover:shadow-lg transform hover:scale-105"
          >
            Hemen Teklif Alın
          </Link>
        </motion.div>
      </motion.section>
    </div>
  );
};

export default ReferanslarPage;

