import React from 'react';

const WhatsAppButton = () => {
  const phoneNumber = "905321234567"; // Placeholder phone number
  const message = "Merhaba, web siteniz üzerinden ulaşıyorum."; // Default message

  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-5 right-5 bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-full shadow-lg z-50 transition-transform duration-300 hover:scale-110 flex items-center"
      aria-label="WhatsApp ile İletişime Geçin"
    >
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" className="w-6 h-6 fill-current">
        <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 .3c87.9 0 159.1 71.2 159.1 159.1 0 46.2-19.9 88.4-53.3 118.4L384 400l-86.4-22.6c-30.3 16.4-64.3 25.1-99.9 25.1-87.9 0-159.1-71.2-159.1-159.1S136 97.4 223.9 97.4zM338.3 325.2c-4.5-2.3-26.6-13.1-30.7-14.6-4.1-1.5-7.1-2.3-10.1 2.3-3 4.5-11.6 14.6-14.2 17.6-2.6 3-5.2 3.4-9.7 1.1-4.5-2.3-18.9-7-36-22.2-13.3-11.7-22.4-26.2-25.1-30.7-2.6-4.5-.3-7.1 2-9.4 2.1-2.1 4.5-5.6 6.8-8.4 2.3-2.8 3-4.5 4.5-7.5 1.5-3 0-5.6-1.1-7.5-1.1-1.9-10.1-24.2-13.8-33.2-3.7-9-7.4-7.8-10.1-7.8h-9.1c-3 0-7.5 1.1-11.6 5.6-4.1 4.5-15.7 15.4-15.7 37.5 0 22.1 16 43.4 18.3 46.2 2.3 2.8 31.4 48.4 76.2 67.6 10.6 4.5 18.9 7.2 25.4 9.2 11.7 3.6 22.4 3 30.7 1.8 9.7-1.4 29.3-12 33.2-23.5 3.9-11.5 3.9-21.4 2.8-23.5-.9-2.2-3.9-3.6-8.4-5.9z"/>
      </svg>
      <span className="ml-2 hidden sm:inline">WhatsApp</span>
    </a>
  );
};

export default WhatsAppButton;

