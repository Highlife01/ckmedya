import Link from 'next/link';
import { motion } from 'framer-motion';
import { useState } from 'react'; // Needed for mobile menu toggle

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItemVariants = {
    hidden: { y: -20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.3 } },
  };

  const mobileMenuVariants = {
    closed: { opacity: 0, height: 0, transition: { duration: 0.3, ease: "easeInOut" } },
    open: { opacity: 1, height: "auto", transition: { duration: 0.4, ease: "easeInOut" } },
  };

  const menuItems = [
    { href: "/", label: "Ana Sayfa" },
    { href: "/hizmetlerimiz", label: "Hizmetlerimiz" },
    { href: "/referanslar", label: "Referanslar" },
    { href: "/blog", label: "Blog" },
    { href: "/iletisim", label: "İletişim" },
  ];

  return (
    <motion.nav 
      className="bg-ck-white text-ck-dark-text p-4 shadow-md sticky top-0 z-50"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-ck-coral hover:opacity-80 transition-opacity">
          CK Medya
        </Link>

        {/* Desktop Menu */}
        <motion.div 
          className="hidden md:flex space-x-6 items-center"
          variants={{ visible: { transition: { staggerChildren: 0.1 } } }}
          initial="hidden"
          animate="visible"
        >
          {menuItems.map((item) => (
            <motion.div key={item.label} variants={navItemVariants}>
              <Link 
                href={item.href} 
                className="hover:text-ck-coral transition-colors duration-300 pb-1 border-b-2 border-transparent hover:border-ck-coral"
              >
                {item.label}
              </Link>
            </motion.div>
          ))}
          <motion.div variants={navItemVariants}>
            <Link 
              href="/iletisim#form" 
              className="bg-ck-coral text-ck-white font-semibold py-2 px-5 rounded-lg hover:bg-opacity-90 transition duration-300 shadow hover:shadow-md transform hover:scale-105"
            >
              Teklif Al
            </Link>
          </motion.div>
        </motion.div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-ck-dark-text focus:outline-none p-2 rounded-md hover:bg-ck-light-gray transition-colors"
            aria-label="Menüyü aç/kapat"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-7 h-7">
              {isMobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <motion.div 
        className="md:hidden overflow-hidden"
        variants={mobileMenuVariants}
        initial="closed"
        animate={isMobileMenuOpen ? "open" : "closed"}
      >
        <div className="flex flex-col space-y-3 pt-4 pb-3 border-t border-ck-light-gray mt-3">
          {menuItems.map((item) => (
            <Link 
              key={item.label} 
              href={item.href} 
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-ck-pale-blue hover:text-ck-coral transition-colors duration-300"
              onClick={() => setIsMobileMenuOpen(false)} // Close menu on click
            >
              {item.label}
            </Link>
          ))}
          <Link 
            href="/iletisim#form" 
            className="block w-full text-center bg-ck-coral text-ck-white font-semibold py-2.5 px-5 rounded-lg hover:bg-opacity-90 transition duration-300 mt-2 shadow hover:shadow-md"
            onClick={() => setIsMobileMenuOpen(false)} // Close menu on click
          >
            Teklif Al
          </Link>
        </div>
      </motion.div>
    </motion.nav>
  );
};

export default Navbar;

