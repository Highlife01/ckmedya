import Link from 'next/link';
import { FaInstagram, FaLinkedinIn, FaTwitter, FaWhatsapp } from 'react-icons/fa'; // Example icons
import { motion } from 'framer-motion';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } },
  };

  const socialIconVariants = {
    hover: { scale: 1.2, rotate: 5, transition: { type: "spring", stiffness: 300 } },
  };

  return (
    <motion.footer 
      className="bg-ck-dark-text text-ck-light-gray p-8 md:p-12 mt-16 md:mt-24"
      variants={footerVariants}
      initial="hidden"
      whileInView="visible" // Animate when in view
      viewport={{ once: true, amount: 0.3 }} // Trigger animation once, when 30% is visible
    >
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        {/* Column 1: About CK Medya */}
        <div className="mb-6 md:mb-0">
          <h3 className="text-xl font-semibold mb-4 text-ck-coral">CK Medya</h3>
          <p className="text-sm text-ck-light-gray/80 leading-relaxed">
            Markanızın dijital dünyadaki parlayan yıldızı olmak için buradayız. Yaratıcı çözümler ve stratejik yaklaşımlarla hedeflerinize ulaşmanızı sağlıyoruz.
          </p>
        </div>

        {/* Column 2: Quick Links */}
        <div className="mb-6 md:mb-0">
          <h3 className="text-lg font-semibold mb-4 text-ck-white">Hızlı Linkler</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="/" className="hover:text-ck-coral transition-colors">Ana Sayfa</Link></li>
            <li><Link href="/hizmetlerimiz" className="hover:text-ck-coral transition-colors">Hizmetlerimiz</Link></li>
            <li><Link href="/referanslar" className="hover:text-ck-coral transition-colors">Referanslar</Link></li>
            <li><Link href="/blog" className="hover:text-ck-coral transition-colors">Blog</Link></li>
            <li><Link href="/iletisim" className="hover:text-ck-coral transition-colors">İletişim</Link></li>
            <li><Link href="/gizlilik-politikasi" className="hover:text-ck-coral transition-colors">Gizlilik Politikası</Link></li>
            <li><Link href="/kullanim-sartlari" className="hover:text-ck-coral transition-colors">Kullanım Şartları</Link></li>
          </ul>
        </div>

        {/* Column 3: Contact Info */}
        <div className="mb-6 md:mb-0">
          <h3 className="text-lg font-semibold mb-4 text-ck-white">Bize Ulaşın</h3>
          <address className="text-sm not-italic space-y-2 text-ck-light-gray/80">
            <p>CK Medya Merkezi, İstanbul</p>
            <p>Telefon: <a href="tel:+905551234567" className="hover:text-ck-coral transition-colors">+90 555 123 4567</a></p>
            <p>E-posta: <a href="mailto:info@ckmedya.com.tr" className="hover:text-ck-coral transition-colors">info@ckmedya.com.tr</a></p>
          </address>
        </div>

        {/* Column 4: Social Media & Newsletter (Conceptual) */}
        <div>
          <h3 className="text-lg font-semibold mb-4 text-ck-white">Sosyal Medyada Biz</h3>
          <div className="flex space-x-4 mb-6">
            <motion.a href="#" target="_blank" rel="noopener noreferrer" className="text-ck-light-gray hover:text-ck-coral transition-colors text-2xl" variants={socialIconVariants} whileHover="hover"><FaInstagram /></motion.a>
            <motion.a href="#" target="_blank" rel="noopener noreferrer" className="text-ck-light-gray hover:text-ck-coral transition-colors text-2xl" variants={socialIconVariants} whileHover="hover"><FaLinkedinIn /></motion.a>
            <motion.a href="#" target="_blank" rel="noopener noreferrer" className="text-ck-light-gray hover:text-ck-coral transition-colors text-2xl" variants={socialIconVariants} whileHover="hover"><FaTwitter /></motion.a>
            <motion.a href="https://wa.me/905551234567" target="_blank" rel="noopener noreferrer" className="text-ck-light-gray hover:text-ck-coral transition-colors text-2xl" variants={socialIconVariants} whileHover="hover"><FaWhatsapp /></motion.a>
          </div>
          {/* Newsletter Signup (Conceptual) */}
          {/* 
          <h3 className="text-lg font-semibold mb-3 text-ck-white">Haberdar Olun</h3>
          <form className="flex">
            <input type="email" placeholder="E-posta adresiniz" className="bg-ck-light-gray/20 text-ck-white placeholder-ck-light-gray/50 px-3 py-2 rounded-l-md focus:ring-2 focus:ring-ck-coral outline-none text-sm w-full" />
            <button type="submit" className="bg-ck-coral text-ck-white px-4 py-2 rounded-r-md hover:bg-opacity-90 transition-colors text-sm font-semibold">Abone Ol</button>
          </form> 
          */}
        </div>
      </div>

      <div className="text-center text-xs text-ck-light-gray/60 mt-10 pt-8 border-t border-ck-light-gray/20">
        © {currentYear} CK Medya İletişim Menajerlik. Tüm hakları saklıdır. Web Tasarım & Geliştirme: Manus.
      </div>
    </motion.footer>
  );
};

export default Footer;

